import info.gridworld.actor.Bug;

public class DancingBug extends Bug		  {
 int[] turns;
 
 int current = 0;
 
 public DancingBug( int[] turns) {
	 
	 this.turns = turns;
 }
 public void turn() {
	 for ( int x = 0; x<turns.length; x++) {
		 turn();
		 
	 } if ( current < turns.length) {
		 
		 current++;
	 } else {
		 current=0;
	 }
	 
 }
 
 
 
}
